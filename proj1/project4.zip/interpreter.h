//
// Created by Cooper Johnston on 3/12/24.
//
#include "datalogProgram.h"
#include "Database.h"
#include "Relation.h"
#include "Tuple.h"
#include <iostream>
class interpreter {
private:
    datalogProgram program;
    Database database;

public:
    interpreter(datalogProgram db) : program(db){


    }
    void evalSchemes(){
        for (int i= 0; i<program.schemes.size(); i++){
            Scheme s = Scheme(program.schemes[i].slist());
            Relation r = Relation(program.schemes[i].name, s);
            //cout << r.toString() << endl;
            database.AddRelation(r);
        }
    }
    void evalFacts(){

        for (int i= 0; i<program.facts.size(); i++){

            Tuple t = Tuple(program.facts.at(i).slist());

            database.add_T(program.facts[i].name, t);



        }

    }
    Relation evalquery(Predicate p){
        Relation found = database.GetCopy(p.name);
        //cout << found.toString() << endl;
        map<string, int> columns;
        vector<string> order;
        for (int i = 0; i < p.plist.size(); i++){
            Parameter j = p.plist.at(i);

            if (j.isConstant){
                found = found.select1(i,j.name);
                //cout << "CONSTant" << j.name << endl;
            }
            else{
                if (columns.find(j.name) != columns.end()){
                    found = found.select2(i, columns.at(j.name));

                }
                else {
                    columns.insert(map<string, int>::value_type(j.name, i));
                    order.push_back(j.name);
                    //cout << j.name;
                }
            }


        }

        found = found.project(order, columns);
        Scheme s = Scheme(order);
        found = found.rename(s);
        return found;
    }
    void evalQs(){
        cout << "Query Evaluation" << endl;
        for (int i = 0; i< program.queries.size(); i++){
            cout << program.queries.at(i).to_string() << "? ";
            Relation r = evalquery(program.queries.at(i));
            if (r.is_empty()){
                cout << "No" <<endl;
            }
            else {
                cout << "Yes(" << r.size() << ")" <<endl;
                cout << r.toString();
            }

        }
    }
    Relation evalRule(Rule r){
        //cout << "Made it to the eval stage" << endl;
        cout << r.to_string() << "." << endl;
        vector<Relation> rlist;
        for (int i = 0; i < r.pred_list.size(); i++){
            Relation j = evalquery(r.pred_list.at(i));
            //cout << j.toString() << endl;
            rlist.push_back(j);
        }

        Relation result = rlist.at(0);
        for (int i =1; i< rlist.size(); i++){
            //cout << rlist.at(i).toString() << endl;
            result = result.join(rlist.at(i));
            //cout << result.toString() << endl;

        }
        //cout <<result.toString() << endl;
        Predicate hp = r.head_pred;
        map<string, int> columns;
        vector<string> order;
        for (int i = 0; i < hp.plist.size(); i ++){
            string id = hp.plist.at(i).name;
            //cout << id << endl;
            order.push_back(id);
            int fa = 0;
            for (int j = 0; j < result.schem.size(); j++){
                //out << j << endl;
                if (result.schem.at(j) == id){
                    break;
                }
                fa ++;

            }
            columns.insert(map<string, int>::value_type(id, fa));
        }


        result = result.project(order,columns);
        //cout << result.toString() << endl;

        Relation * g = database.GetRelation(hp.name);
        //cout<< g->schem.size() << endl;
        Relation correct = database.GetCopy(hp.name);
        //cout << correct.toString() << endl;


        result = result.rename(correct.schem);
        //cout << (*correct).toString() << endl;
        (&correct)->unionize(result);
        //cout << correct.toString() << endl;
        for (auto itr: result.tuples){
            database.add_T(correct.g_name(),itr);
        }
        return correct;
    }
    void evalRules(){
        cout << "Rule Evaluation"  << endl;
        int count = 0;
        //cout << program.rules.at(0).to_string() << endl;
        //find the number of tuples in the relations
        while (true) {
            int prev = database.tupleCount();
            //cout << "DEBUG in the loop!" << endl;
            for (int i = 0; i < program.rules.size(); i++) {
                //cout << "DEBUG in the loop!" << endl;
                Relation newRule = evalRule(program.rules.at(i));

            }
            int cur = database.tupleCount();
            count ++;
            if (prev == cur){
                break;
            }
        }
        cout << "\n";
        cout << "Schemes populated after " << count << " passes through the Rules." << endl;
        cout << "\n";


    }


};